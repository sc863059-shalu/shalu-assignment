# Shalu Assignment

This is a simple React project created as part of the assignment.

## How to run

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

The app will run on [http://localhost:5173](http://localhost:5173)
