import React from 'react'

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Shalu's Assignment</h1>
      <p>This project was built using React + Vite.</p>
    </div>
  )
}

export default App
